import base64,hashlib,io,json,os,pathlib,platform,subprocess,sys,time,zipfile
data=json.loads(sys.argv[1])
root=pathlib.Path("/dev/estate-sources-fanout63-c4c3dc26dd94")
assert os.statvfs("/dev").f_bavail*os.statvfs("/dev").f_frsize>8*1024*1024
root.mkdir(mode=0o700)
def git(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(b)
def identity(p):
 s=p.stat();b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=git(b),inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
def run(command,cwd,label):
 started=time.monotonic()
 p=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"))
 timed=False
 try:out,err=p.communicate(timeout=10)
 except subprocess.TimeoutExpired:
  timed=True;p.kill();out,err=p.communicate(timeout=3)
 put(root/(label+".stdout.bin"),out);put(root/(label+".stderr.bin"),err)
 result=dict(argv=command,cwd=str(cwd),pid=p.pid,exit=p.returncode,reaped=p.poll() is not None,timed_out=timed,seconds=time.monotonic()-started,stdout=out.decode("utf-8","backslashreplace"),stderr=err.decode("utf-8","backslashreplace"))
 assert not timed and result["reaped"]
 return result,out,err
seed='''from pathlib import Path
import json,sqlite3
from fanout_engine import Ledger,Part,Plan
directory=Path("fixtures");directory.mkdir()
database=directory/"selected.sqlite3"
plan=Plan("sample",(Part("work","Produce résumé"),Part("pending","No recorded part event.")))
with Ledger(str(database)) as ledger:
 ledger.record_plan(plan)
 ledger.mark_dispatching("sample","work","fixture-worker",{"model":"local-fixture","effort":"high"})
 ledger.mark_running("sample","work","fixture-task")
 ledger.mark_completed("sample","work","fixture://résumé",{"source":"fixture","locator":"fixture://work","finding":"Authored completion."})
 ledger._db.execute("UPDATE events SET at=-seq")
 events=ledger.events("sample")
expected={"schema_version":1,"project_id":plan.project_id,"plan_digest":plan.digest,"part_id":None,"events":events}
selected={**expected,"part_id":"work","events":[e for e in events if e["part_id"]=="work"]}
bad=directory/"invalid.sqlite3";bad.write_bytes(database.read_bytes())
con=sqlite3.connect(bad)
with con:con.execute("UPDATE events SET detail_json='not JSON' WHERE part_id IS NULL")
con.close()
(directory/"occupied.json").write_bytes(b"preserve existing report\\n")
print(json.dumps({"full":expected,"selected":selected},ensure_ascii=False))
'''
put(root/"CRITERIA.json",data["criteria"].encode())
put(root/"run_composition.py",sys.argv[2].encode())
courses=[]
for name,changed in [("original",False),("candidate",True)]:
 directory=root/name;directory.mkdir()
 for path,item in data["files"].items():
  if changed and path=="fanout_engine/history.py":item=data["candidate"]
  b=item["content"].encode();assert git(b)==item["sha"],path;put(directory/path,b)
 put(directory/"seed.py",seed.encode())
 before={p:identity(directory/p) for p in data["files"]}
 seed_result,seed_out,seed_err=run([sys.executable,"-S","-B","seed.py"],directory,name+"-seed")
 assert seed_result["exit"]==0 and seed_err==b"",seed_result
 expected=json.loads(seed_out)
 assert [e["seq"] for e in expected["full"]["events"]]==[1,2,3,4]
 assert [e["seq"] for e in expected["selected"]["events"]]==[2,3,4]
 fixtures={p:identity(directory/"fixtures"/p) for p in ("selected.sqlite3","invalid.sqlite3","occupied.json")}
 command=[sys.executable,"-S","-B","-m","fanout_engine.history","--database","fixtures/selected.sqlite3","--project","sample"]
 full,full_bytes,err=run(command,directory,name+"-stdout-full")
 selected,selected_bytes,selected_err=run(command+["--part","work"],directory,name+"-stdout-selected")
 for key,proc,out,stderr in [("full",full,full_bytes,err),("selected",selected,selected_bytes,selected_err)]:
  exact=(json.dumps(expected[key],sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)+"\n").encode()
  assert proc["exit"]==0 and not stderr and out==exact,(key,proc)
 cases=[]
 ordinary,out,err=run(command+["--part","work","--output","fixtures/history résumé.json"],directory,name+"-ordinary")
 target=directory/"fixtures/history résumé.json"
 desired=ordinary["exit"]==0 and out==err==b"" and target.exists() and target.read_bytes()==selected_bytes
 if changed:assert desired,ordinary
 else:assert ordinary["exit"]==2 and out==b"" and b"unrecognized arguments: --output" in err and not target.exists()
 cases.append(dict(name="selected_new_file",desired_pass=desired,process=ordinary,output_present=target.exists()))
 occupied,out,err=run(command+["--output","fixtures/occupied.json"],directory,name+"-occupied")
 desired=occupied["exit"]==1 and out==b"" and b"cannot write report" in err and b"Traceback" not in err
 if changed:assert desired,occupied
 else:assert occupied["exit"]==2 and out==b"" and b"unrecognized arguments: --output" in err
 assert identity(directory/"fixtures/occupied.json")==fixtures["occupied.json"]
 cases.append(dict(name="occupied_file",desired_pass=desired,process=occupied))
 reserved,out,err=run(command+["--output","fixtures/selected.sqlite3-wal"],directory,name+"-reserved")
 target=directory/"fixtures/selected.sqlite3-wal"
 desired=reserved["exit"]==1 and out==b"" and b"cannot write report" in err and b"SQLite sidecar" in err and b"Traceback" not in err and not target.exists()
 if changed:assert desired,reserved
 else:assert reserved["exit"]==2 and out==b"" and b"unrecognized arguments: --output" in err and not target.exists()
 cases.append(dict(name="selected_absent_wal",desired_pass=desired,process=reserved,output_present=target.exists()))
 invalid,out,err=run([sys.executable,"-S","-B","-m","fanout_engine.history","--database","fixtures/invalid.sqlite3","--project","sample","--part","pending","--output","fixtures/invalid.sqlite3-wal"],directory,name+"-invalid")
 target=directory/"fixtures/invalid.sqlite3-wal"
 desired=invalid["exit"]==2 and out==b"" and b"invalid_record" in err and b"cannot write report" not in err and b"Traceback" not in err and not target.exists()
 if changed:assert desired,invalid
 else:assert invalid["exit"]==2 and out==b"" and b"unrecognized arguments: --output" in err and not target.exists()
 cases.append(dict(name="invalid_excluded_event_precedence",desired_pass=desired,process=invalid,output_present=target.exists()))
 assert not list(directory.rglob(".fanout-preview-*"))
 after={p:identity(directory/p) for p in before};fixtures_after={p:identity(directory/"fixtures"/p) for p in fixtures}
 assert before==after and fixtures==fixtures_after
 courses.append(dict(name=name,expected_reports=expected,seed=seed_result,stdout_controls=[full,selected],cases=cases,desired_passes=sum(c["desired_pass"] for c in cases),source_before=before,source_after=after,fixtures_before=fixtures,fixtures_after=fixtures_after,source_and_fixture_identities_unchanged=True))
result=dict(base=data["base"],owner_head=data["owner"],python=sys.version,platform=platform.platform(),scope="nine-file current runtime projection; four owned-fixture output behaviors plus full/selected stdout and seed controls; no maintained matrix, native, installed or live-ledger course",courses=courses,qualified=True)
qualification_text=json.dumps(result,indent=2,ensure_ascii=False)+"\n"
put(root/"qualification.json",qualification_text.encode())
files=sorted(p for p in root.rglob("*") if p.is_file())
manifest={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),git=git(p.read_bytes())) for p in files}
buf=io.BytesIO()
with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
 for p in files:z.writestr(str(p.relative_to(root)),p.read_bytes())
 z.writestr("MANIFEST.json",json.dumps(manifest,indent=2)+"\n")
archive=buf.getvalue()
print(json.dumps(dict(qualification_text=qualification_text,summary=dict(desired=[c["desired_passes"] for c in courses],exits=[[x["process"]["exit"] for x in c["cases"]] for c in courses],children=sum(1+len(c["stdout_controls"])+len(c["cases"]) for c in courses),qualified=True),archive=dict(bytes=len(archive),sha256=hashlib.sha256(archive).hexdigest(),git=git(archive),base64=base64.b64encode(archive).decode()),manifest=manifest)))
