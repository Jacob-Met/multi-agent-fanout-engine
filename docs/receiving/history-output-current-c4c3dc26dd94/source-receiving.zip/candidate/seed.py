from pathlib import Path
import json,sqlite3
from fanout_engine import Ledger,Part,Plan
directory=Path("fixtures");directory.mkdir()
database=directory/"selected.sqlite3"
plan=Plan("sample",(Part("work","Produce résumé"),Part("pending","No recorded part event.")))
with Ledger(str(database)) as ledger:
 ledger.record_plan(plan)
 ledger.mark_dispatching("sample","work","fixture-worker",{"model":"local-fixture","effort":"high"})
 ledger.mark_running("sample","work","fixture-task")
 ledger.mark_completed("sample","work","fixture://résumé",{"source":"fixture","locator":"fixture://work","finding":"Authored completion."})
 ledger._db.execute("UPDATE events SET at=-seq")
 events=ledger.events("sample")
expected={"schema_version":1,"project_id":plan.project_id,"plan_digest":plan.digest,"part_id":None,"events":events}
selected={**expected,"part_id":"work","events":[e for e in events if e["part_id"]=="work"]}
bad=directory/"invalid.sqlite3";bad.write_bytes(database.read_bytes())
con=sqlite3.connect(bad)
with con:con.execute("UPDATE events SET detail_json='not JSON' WHERE part_id IS NULL")
con.close()
(directory/"occupied.json").write_bytes(b"preserve existing report\n")
print(json.dumps({"full":expected,"selected":selected},ensure_ascii=False))
