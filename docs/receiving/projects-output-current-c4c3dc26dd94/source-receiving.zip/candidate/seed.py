from pathlib import Path
import json,sqlite3
from fanout_engine import Ledger,Part,Plan
directory=Path("fixtures")
directory.mkdir()
plans=[Plan("Alpha",(Part("pending","Local fixture."),)),Plan("zulu",(Part("pending","Later local fixture."),))]
database=directory/"selected.sqlite3"
with Ledger(str(database)) as ledger:
 for plan in plans:ledger.record_plan(plan)
bad=directory/"invalid.sqlite3";bad.write_bytes(database.read_bytes())
con=sqlite3.connect(bad)
with con:con.execute("UPDATE projects SET plan_json='{}' WHERE project_id='zulu'")
con.close()
print(json.dumps({"schema_version":1,"project_count":2,"projects":[{"project_id":p.project_id,"plan_digest":p.digest,"part_count":1} for p in plans]}))
