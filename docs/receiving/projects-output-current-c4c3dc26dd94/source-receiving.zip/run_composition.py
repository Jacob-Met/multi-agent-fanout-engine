import base64,hashlib,io,json,os,pathlib,platform,subprocess,sys,time,zipfile
data=json.loads(sys.argv[1])
root=pathlib.Path("/dev/estate-sources-fanout66-c4c3dc26dd94")
assert os.statvfs("/dev").f_bavail*os.statvfs("/dev").f_frsize>8*1024*1024
root.mkdir(mode=0o700)
def git(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(b)
def identity(p):
 s=p.stat();b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=git(b),inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
def run(command,cwd,label):
 started=time.monotonic();p=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"))
 timed=False
 try:out,err=p.communicate(timeout=10)
 except subprocess.TimeoutExpired:
  timed=True;p.kill();out,err=p.communicate(timeout=3)
 put(root/(label+".stdout.bin"),out);put(root/(label+".stderr.bin"),err)
 result=dict(argv=command,cwd=str(cwd),pid=p.pid,exit=p.returncode,reaped=p.poll() is not None,timed_out=timed,seconds=time.monotonic()-started,stdout=out.decode("utf-8","backslashreplace"),stderr=err.decode("utf-8","backslashreplace"))
 assert not timed and result["reaped"]
 return result,out,err
seed='''from pathlib import Path
import json,sqlite3
from fanout_engine import Ledger,Part,Plan
directory=Path("fixtures")
directory.mkdir()
plans=[Plan("Alpha",(Part("pending","Local fixture."),)),Plan("zulu",(Part("pending","Later local fixture."),))]
database=directory/"selected.sqlite3"
with Ledger(str(database)) as ledger:
 for plan in plans:ledger.record_plan(plan)
bad=directory/"invalid.sqlite3";bad.write_bytes(database.read_bytes())
con=sqlite3.connect(bad)
with con:con.execute("UPDATE projects SET plan_json='{}' WHERE project_id='zulu'")
con.close()
print(json.dumps({"schema_version":1,"project_count":2,"projects":[{"project_id":p.project_id,"plan_digest":p.digest,"part_count":1} for p in plans]}))
'''
courses=[]
for name,changed in [("original",False),("candidate",True)]:
 directory=root/name;directory.mkdir()
 for path,item in data["files"].items():
  if changed and path=="fanout_engine/projects.py":item=data["candidate"]
  b=item["content"].encode();assert git(b)==item["sha"],path;put(directory/path,b)
 put(directory/"seed.py",seed.encode())
 before={p:identity(directory/p) for p in data["files"]}
 seed_result,seed_out,seed_err=run([sys.executable,"-S","-B","seed.py"],directory,name+"-seed")
 assert seed_result["exit"]==0 and seed_err==b""
 expected=json.loads(seed_out)
 fixtures={p:identity(directory/"fixtures"/p) for p in ("selected.sqlite3","invalid.sqlite3")}
 command=[sys.executable,"-S","-B","-m","fanout_engine.projects","--database","fixtures/selected.sqlite3"]
 stdout,normal_bytes,err=run(command,directory,name+"-stdout")
 assert stdout["exit"]==0 and not err and json.loads(normal_bytes)==expected
 ordinary,out,err=run(command+["--output","fixtures/catalog.json"],directory,name+"-ordinary")
 ordinary_ok=ordinary["exit"]==0 and out==err==b"" and (directory/"fixtures/catalog.json").read_bytes()==normal_bytes
 assert ordinary_ok
 reserved,out,err=run(command+["--output","fixtures/selected.sqlite3-wal"],directory,name+"-reserved")
 destination=directory/"fixtures/selected.sqlite3-wal"
 desired_reserved=reserved["exit"]==1 and out==b"" and b"cannot write catalog" in err and b"SQLite sidecar" in err and not destination.exists()
 if changed:assert desired_reserved
 else:assert reserved["exit"]==0 and out==err==b"" and destination.read_bytes()==normal_bytes
 invalid,out,err=run([sys.executable,"-S","-B","-m","fanout_engine.projects","--database","fixtures/invalid.sqlite3","--output","fixtures/invalid.sqlite3-wal"],directory,name+"-invalid")
 invalid_ok=invalid["exit"]==2 and out==b"" and b"invalid_record" in err and not (directory/"fixtures/invalid.sqlite3-wal").exists()
 assert invalid_ok and b"cannot write catalog" not in err
 assert not list(directory.rglob(".fanout-preview-*"))
 after={p:identity(directory/p) for p in before};fixtures_after={p:identity(directory/"fixtures"/p) for p in fixtures}
 assert before==after and fixtures==fixtures_after
 courses.append(dict(name=name,expected_catalog=expected,seed=seed_result,stdout_control=stdout,cases=[dict(name="ordinary",desired_pass=ordinary_ok,process=ordinary),dict(name="reserved_selected_wal",desired_pass=desired_reserved,process=reserved,output_present=destination.exists()),dict(name="invalid_plan_precedence",desired_pass=invalid_ok,process=invalid)],desired_passes=sum((ordinary_ok,desired_reserved,invalid_ok)),source_before=before,source_after=after,fixtures_before=fixtures,fixtures_after=fixtures_after,source_and_database_identities_unchanged=True))
result=dict(base=data["base"],owner_head=data["owner"],python=sys.version,platform=platform.platform(),scope="nine-file current runtime projection; three owned-fixture behaviors plus stdout/seed controls; no broad filename, native, installed or live-ledger course",courses=courses,qualified=True)
put(root/"qualification.json",(json.dumps(result,indent=2)+"\n").encode())
put(root/"run_composition.py",sys.argv[2].encode())
files=sorted(p for p in root.rglob("*") if p.is_file())
manifest={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),git=git(p.read_bytes())) for p in files}
buf=io.BytesIO()
with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
 for p in files:z.writestr(str(p.relative_to(root)),p.read_bytes())
 z.writestr("MANIFEST.json",json.dumps(manifest,indent=2)+"\n")
archive=buf.getvalue()
print(json.dumps(dict(result=result,archive=dict(bytes=len(archive),sha256=hashlib.sha256(archive).hexdigest(),git=git(archive),base64=base64.b64encode(archive).decode()),manifest=manifest)))
