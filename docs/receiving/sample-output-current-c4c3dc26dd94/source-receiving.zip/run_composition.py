import base64, hashlib, io, json, os, pathlib, platform, subprocess, sys, time, zipfile
data=json.loads(sys.argv[1])
root=pathlib.Path("/dev/estate-sources-fanout62-c4c3dc26dd94")
if os.statvfs("/dev").f_bavail*os.statvfs("/dev").f_frsize < 8*1024*1024: raise SystemExit("insufficient private fixture capacity")
root.mkdir(mode=0o700)
def git(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\\0".decode("unicode_escape").encode()+b).hexdigest()
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb") as f:f.write(b)
def ident(p):
 s=p.stat();b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git=git(b),inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
def stage(name,candidate):
 directory=root/name;directory.mkdir()
 rows={}
 for path,v in data["files"].items():
  if candidate and path=="examples/create_retained_ledger.py":v=data["candidate"]
  b=v["content"].encode();assert git(b)==v["sha"],path
  p=directory/path;put(p,b);rows[path]=ident(p)
 for path,key in [("tests/test_sample_creator_output.py","test"),("docs/sample-creator-output.md","guide")]:
  v=data[key];b=v["content"].encode();assert git(b)==v["sha"]
  p=directory/path;put(p,b);rows[path]=ident(p)
 (directory/"temporary").mkdir()
 return directory,rows
receipts=[]
for name,candidate in [("original",False),("candidate",True)]:
 directory,before=stage(name,candidate)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",TMPDIR=str(directory/"temporary"))
 cmd=[sys.executable,"-S","-B","-m","unittest","discover","-s","tests","-p","test_sample_creator_output.py","-v"]
 start=time.monotonic();child=subprocess.Popen(cmd,cwd=directory,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 timed_out=False
 try:out,err=child.communicate(timeout=45)
 except subprocess.TimeoutExpired:
  timed_out=True;child.kill();out,err=child.communicate(timeout=5)
 after={p:ident(directory/p) for p in before}
 put(root/(name+".stdout.bin"),out);put(root/(name+".stderr.bin"),err)
 receipt=dict(name=name,argv=cmd,cwd=str(directory),pid=child.pid,exit=child.returncode,reaped=child.poll() is not None,timed_out=timed_out,seconds=time.monotonic()-start,before=before,after=after,source_identities_unchanged=before==after,stdout=out.decode("utf-8","backslashreplace"),stderr=err.decode("utf-8","backslashreplace"))
 receipts.append(receipt)
 assert before==after and not timed_out
 assert b"Ran 6 tests" in err
 if candidate:assert child.returncode==0 and err.endswith(b"OK\n"),err
 else:assert child.returncode==1 and b"FAILED (failures=2)" in err and b"UnicodeEncodeError" in err,err
result=dict(base=data["base"],owner_head=data["owner_head"],venue=platform.platform(),python=sys.version,source_scope="seven current runtime source files plus unchanged owner test and guide; no full checkout, Windows/native or installed qualification",receipts=receipts,qualified=True)
put(root/"qualification.json",(json.dumps(result,indent=2,ensure_ascii=True)+"\n").encode())
put(root/"run_composition.py",pathlib.Path("/proc/self/cmdline").read_bytes().split(b"\0")[3] if False else sys.argv[2].encode())
files=sorted(p for p in root.rglob("*") if p.is_file())
manifest={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),git=git(p.read_bytes())) for p in files}
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,"w",zipfile.ZIP_DEFLATED) as z:
 for p in files:z.writestr(str(p.relative_to(root)),p.read_bytes())
 z.writestr("MANIFEST.json",json.dumps(manifest,indent=2)+"\n")
archive=buffer.getvalue()
print(json.dumps(dict(result=result,archive=dict(bytes=len(archive),sha256=hashlib.sha256(archive).hexdigest(),git=git(archive),base64=base64.b64encode(archive).decode()),manifest=manifest)))
