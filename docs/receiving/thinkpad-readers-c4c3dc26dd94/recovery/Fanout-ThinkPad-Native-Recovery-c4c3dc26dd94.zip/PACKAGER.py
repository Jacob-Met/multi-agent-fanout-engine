import base64, hashlib, json, pathlib, stat, zipfile

ROOT=pathlib.Path(__file__).resolve().parent
ARCHIVE=ROOT/'Fanout-ThinkPad-Native-Recovery-c4c3dc26dd94.zip'

def pin(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}

def read(p):
    for a in list(p.parents)[:-1]:
        if not stat.S_ISDIR(a.lstat().st_mode):raise ValueError('non-directory ancestor')
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):raise ValueError('nonregular input')
    b=p.read_bytes();m={'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns,**pin(b)}
    if len(b)!=s.st_size:raise ValueError('changed size')
    return b,m

export=json.loads((ROOT/'native-recovery.json').read_bytes())
freeze=json.loads((ROOT/'ORIGINAL-NATIVE-FREEZE.json').read_bytes())
assert export['count']==17 and export['all_identities_unchanged']
assert export['alias_before']==export['alias_after']==freeze['descriptors']['installed_alias']
payload={};before={}
names=['README.md','PACKAGER.py','recover_native.py','native-recovery.json','ORIGINAL-NATIVE-FREEZE.json','native-start-connector.json','native-outer-connector.json','git-recovery-publication.json','peer/receiving.json','peer/first-adapter-error.json']
names += ['raw/'+n for n in export['files']]
assert len(names)==27 and len(set(names))==27
for name in names:
    p=pathlib.PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
    payload[name],before[name]=read(ROOT/name)
for name,row in export['files'].items():
    b=payload['raw/'+name];expected=freeze['files'][name]
    assert base64.b64decode(row['base64'],validate=True)==b
    assert pin(b)=={k:row[k] for k in ('bytes','sha256','git')}=={k:expected[k] for k in ('bytes','sha256','git')}
    assert row['before']==row['after'] and all(row['before'][k]==expected[k] for k in row['before'])
assert pin(payload['native-recovery.json'])['git']=='981efdb972af836fe2829fe76f52a7f2d222877d'
assert pin(payload['ORIGINAL-NATIVE-FREEZE.json'])['git']=='4b315d4ed346e200b84d2b34edcb55c8c77e1eb9'
manifest={'schema':'fanout.native-recovery-companion.v1','files':{n:pin(b) for n,b in payload.items()},'cloud_inputs':before,'scope':'Additive data-only evidence; 17 recovered original native bodies plus original 86-file descriptor map. No native/product execution by packager.'}
payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):
        i=zipfile.ZipInfo(n);i.create_system=3;i.external_attr=(stat.S_IFREG|0o600)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.namelist()==sorted(payload) and z.testzip() is None
    for n,b in payload.items():assert z.read(n)==b
for n,row in before.items():
    b,m=read(ROOT/n);assert m==row and b==payload[n]
result={'accepted':True,'archive':str(ARCHIVE),**pin(ARCHIVE.read_bytes()),'members':28,'payloads':27,'native_bodies':17,'all_cloud_inputs_unchanged':True,'before':before,'scope':'Data-only packaging, no source or archived code execution'}
with (ROOT/'package-receiving.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='before'}))
