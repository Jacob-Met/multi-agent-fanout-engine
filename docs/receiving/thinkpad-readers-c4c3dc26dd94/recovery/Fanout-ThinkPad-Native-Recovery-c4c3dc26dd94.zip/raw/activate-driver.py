import hashlib,json,subprocess
from pathlib import Path
r=Path("/home/jacob/fanout-readers-20261013-c4c3dc26dd94")
source=r/"install_readers.py"; helper=r/"receive_local.py"; archive=r/"Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip"
assert hashlib.sha256(source.read_bytes()).hexdigest()=="696ced62021048a0de9d7cc01d515fe865a8ab34d26583455f933efd3b63cb63"
assert hashlib.sha256(helper.read_bytes()).hexdigest()=="ef853e1b9fd005f281e195132d99098e5fbfc818d6f9ad1987e398e53b4f48c7"
argv=["/usr/bin/python3.14","-I","-B",str(helper),"--output-dir",str(r/"activation-job"),"--cwd",str(r),"--timeout","60","--source",str(source),"--source",str(archive),"--source",str(r/"staged-receipt.json"),"--","/usr/bin/python3.14","-I","-B",str(source),"activate"]
print(json.dumps({"phase":"activate","argv":argv}),flush=True)
p=subprocess.run(argv)
print(json.dumps({"helper_exit":p.returncode,"receipt":str(r/"activation-job/receipt.json")}),flush=True)
raise SystemExit(p.returncode)
