import os, pwd, socket, stat, sys, hashlib, json
from pathlib import Path
expected={"/home/jacob":(66306,262146),"/home/jacob/.local":(66306,262152),"/home/jacob/.local/bin":(66306,412413),"/home/jacob/.local/share":(66306,262153),"/home/jacob/.local/share/hamon-tools":(66306,4594380)}
rows={}
for name,pair in expected.items():
 s=Path(name).lstat()
 rows[name]={"dev":s.st_dev,"ino":s.st_ino,"mode":s.st_mode,"uid":s.st_uid,"gid":s.st_gid,"accepted":stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==1000 and (s.st_dev,s.st_ino)==pair}
py=Path(sys.executable).resolve()
name="hamon-fanout-read"
collisions=[str(Path(p or ".")/name) for p in os.environ.get("PATH","").split(os.pathsep) if os.path.lexists(Path(p or ".")/name)]
print(json.dumps({"host":socket.gethostname(),"account":pwd.getpwuid(os.getuid()).pw_name,"uid":os.getuid(),"gid":os.getgid(),"python":str(py),"version":sys.version,"python_sha256":hashlib.sha256(py.read_bytes()).hexdigest(),"directories":rows,"path":os.environ.get("PATH"),"collisions":collisions,"work_exists":os.path.lexists("/home/jacob/fanout-readers-20261013-c4c3dc26dd94"),"version_exists":os.path.lexists("/home/jacob/.local/share/hamon-tools/hamon-fanout-read-639038bb09a1"),"read_only":True},indent=2))
