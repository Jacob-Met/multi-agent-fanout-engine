import base64,hashlib,json,os,subprocess
from pathlib import Path
r=Path("/home/jacob/fanout-readers-20261013-c4c3dc26dd94")
source=r/"install_readers.py"; helper=r/"receive_local.py"
assert hashlib.sha256(source.read_bytes()).hexdigest()=="696ced62021048a0de9d7cc01d515fe865a8ab34d26583455f933efd3b63cb63"
assert hashlib.sha256(helper.read_bytes()).hexdigest()=="ef853e1b9fd005f281e195132d99098e5fbfc818d6f9ad1987e398e53b4f48c7"
data=base64.b64decode((r/"build-archive.b64").read_bytes(),validate=True)
assert len(data)==114764 and hashlib.sha256(data).hexdigest()=="f6bacba529169097b44804a3fe1ba63c4e778d569ac585b9e389ba1cf12ab65b"
archive=r/"Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip"
with archive.open("xb") as f:f.write(data)
archive.chmod(0o600)
argv=["/usr/bin/python3.14","-I","-B",str(helper),"--output-dir",str(r/"stage-job"),"--cwd",str(r),"--timeout","240","--source",str(source),"--source",str(archive),"--","/usr/bin/python3.14","-I","-B",str(source),"stage"]
print(json.dumps({"phase":"stage","argv":argv}),flush=True)
p=subprocess.run(argv)
print(json.dumps({"helper_exit":p.returncode,"receipt":str(r/"stage-job/receipt.json")}),flush=True)
raise SystemExit(p.returncode)
