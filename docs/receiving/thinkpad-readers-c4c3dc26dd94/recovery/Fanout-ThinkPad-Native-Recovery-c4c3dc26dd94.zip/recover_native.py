import os,sys,pathlib,stat,json,hashlib,base64,pwd,socket
F=pathlib.Path('/home/jacob/fanout-readers-20261013-c4c3dc26dd94/FREEZE.json')
NAMES=['installation-receipt.json', 'stage-driver.py', 'activate-driver.py', 'preflight-driver.py', 'connector-observations.json', 'activation-job/receipt.json', 'activation-job/spawned.json', 'activation-job/started.json', 'activation-job/stderr.bin', 'activation-job/stdout.bin', 'activation/inherited-help.json', 'activation/inherited-help.stdout.bin', 'activation/inherited-help.stderr.bin', 'activation/inherited-history.json', 'activation/inherited-history.stdout.bin', 'activation/inherited-history.stderr.bin', 'runtime/hamon-fanout-read']
FH='45acfb24493fb86df9126ac85f08f707e691eef0570abaa04cd28212730695a3'
EXE='/usr/bin/python3.14'
EH='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
ALIAS=pathlib.Path('/home/jacob/.local/bin/hamon-fanout-read')
def need(c,m):
 if not c: raise RuntimeError(m)
def meta(s):
 return dict(dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,size=s.st_size)
def read(p):
 p=pathlib.Path(p)
 for a in list(p.parents)[:-1]: need(stat.S_ISDIR(a.lstat().st_mode),'nonregular ancestor '+str(a))
 before=meta(p.lstat());need(stat.S_ISREG(before['mode']),'not regular '+str(p))
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  need(meta(os.fstat(fd))==before,'descriptor changed '+str(p))
  with os.fdopen(fd,'rb',closefd=False) as h: b=h.read(20_000_001 if str(p)==EXE else 2_000_001)
 finally: os.close(fd)
 need(len(b)<=(20_000_000 if str(p)==EXE else 2_000_000) and len(b)==before['size'],'size bound '+str(p))
 need(meta(p.lstat())==before,'read changed '+str(p))
 return b,before
def alias():
 s=ALIAS.lstat();need(stat.S_ISLNK(s.st_mode),'alias not symlink')
 return dict(meta(s),target=os.readlink(ALIAS))
need(os.getuid()==1000 and pwd.getpwuid(os.getuid()).pw_name=='jacob','account')
need(socket.gethostname()=='hamon-thinkpad','host')
need(sys.executable==EXE and sys.version_info[:3]==(3,14,4),'python')
eb,ei=read(EXE);need(hashlib.sha256(eb).hexdigest()==EH,'python hash')
fb,fi=read(F);need(hashlib.sha256(fb).hexdigest()==FH,'freeze hash')
f=json.loads(fb);need(f['native_regular_inputs']==86,'freeze count')
ab=alias();need(ab==f['descriptors']['installed_alias'],'alias before')
files={}
for n in NAMES:
 row=f['files'][n];p=pathlib.Path(row['native_path']);b,m=read(p)
 need(all(m[k]==row[k] for k in m),'identity '+n)
 need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'hash '+n)
 need(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git'],'git '+n)
 files[n]={'native_path':str(p),'before':m,'bytes':len(b),'sha256':row['sha256'],'git':row['git'],'base64':base64.b64encode(b).decode('ascii')}
for n,v in files.items():
 b,m=read(v['native_path']);need(m==v['before'] and hashlib.sha256(b).hexdigest()==v['sha256'],'after '+n);v['after']=m
fb2,fi2=read(F);need(fb2==fb and fi2==fi,'freeze after')
eb2,ei2=read(EXE);need(eb2==eb and ei2==ei,'python after')
aa=alias();need(aa==ab,'alias after')
print(json.dumps({'schema':'fanout.native.missing-body-recovery.c4c3dc26dd94.v1','scope':'Read-only recovery of seventeen previously descriptor-only retained files; no product, installer, alias or source execution/mutation. Prior portable packet remains unchanged.','identity':{'user':'jacob','uid':1000,'host':socket.gethostname(),'executable':EXE,'python_sha256':EH},'freeze':{'path':str(F),'bytes':len(fb),'sha256':FH,'before':fi,'after':fi2},'alias_before':ab,'alias_after':aa,'files':files,'count':len(files),'all_identities_unchanged':True},indent=2))
