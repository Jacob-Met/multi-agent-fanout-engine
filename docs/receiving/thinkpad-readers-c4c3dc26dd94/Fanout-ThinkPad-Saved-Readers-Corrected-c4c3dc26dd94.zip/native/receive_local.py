"""Receive one foreground local command and retain its actual result.

Standalone: python receive_local.py --output-dir NEW --cwd DIR --timeout 60
            [--source FILE ...] -- /absolute/program arg ...
No host policy, remote transport, shell, detached job or automatic retry is used.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import threading
import time


def _snapshot(path):
    """Hash one regular file; nonblocking admission avoids FIFO open hangs."""
    path = Path(path)
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0)
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError(f"not a regular file: {path}")
        digest = hashlib.sha256()
        while chunk := os.read(fd, 1024 * 1024):
            digest.update(chunk)
        after = os.fstat(fd)
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
        if identity(before) != identity(after):
            raise ValueError(f"file changed while hashing: {path}")
        return {"path": str(path), "sha256": digest.hexdigest(),
                "bytes": after.st_size, "device": after.st_dev,
                "inode": after.st_ino, "mtime_ns": after.st_mtime_ns}
    finally:
        os.close(fd)


def _write_record(path, value):
    """Publish complete JSON only after flushing its exclusive temporary file."""
    temporary = path.with_name("." + path.name + ".pending")
    with temporary.open("xb") as stream:
        stream.write((json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode("utf-8"))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _kill_and_reap(process):
    if process.poll() is None:
        try:
            process.kill()
        except ProcessLookupError:
            pass
    return process.wait()


def receive(argv, cwd, output_dir, timeout, sources=()):
    """Run once. Return the receiver code; the receipt retains the native code."""
    cwd = Path(cwd).resolve(strict=True)
    if not cwd.is_dir():
        raise ValueError("cwd must be an existing directory")
    if not argv or not Path(argv[0]).is_absolute():
        raise ValueError("command must begin with an absolute executable path")
    if any(not isinstance(arg, str) or "\0" in arg for arg in argv):
        raise ValueError("command arguments must be strings without NUL")
    if not math.isfinite(timeout) or not 0 < timeout < threading.TIMEOUT_MAX:
        raise ValueError("timeout must be positive, finite and below threading.TIMEOUT_MAX")
    output = Path(output_dir).absolute()
    # Preserve caller spellings in argv; resolved files are separately identified.
    paths = [Path(__file__).resolve(), Path(argv[0]).resolve(strict=True)]
    paths.extend((cwd / path).absolute() for path in sources)
    paths = list(dict.fromkeys(paths))
    before = [_snapshot(path) for path in paths]
    output.mkdir(mode=0o700)  # Exclusive: an old or incomplete receipt is never reused.
    prepared_ns = time.time_ns()
    started = {"schema": "hamon.host_job.receive_local.v1", "state": "prepared",
               "argv": list(argv), "cwd": str(cwd), "timeout_seconds": timeout,
               "output_dir": str(output), "prepared_ns": prepared_ns,
               "environment": "inherited; values not recorded", "stdin": "null",
               "sources_before": before, "child_start_confirmed": False}
    process = None
    native_code = None
    outcome = "receiver_error"
    receiver_code = 74
    detail = None
    elapsed_start = time.monotonic()
    try:
        with (output / "stdout.bin").open("xb") as stdout, (output / "stderr.bin").open("xb") as stderr:
            _write_record(output / "started.json", started)
            try:
                process = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr, shell=False)
            except OSError as exc:
                outcome, receiver_code, detail = "spawn_error", 127, str(exc)
            if process is not None:
                _write_record(output / "spawned.json",
                              {"pid": process.pid, "observed_ns": time.time_ns(),
                               "child_start_confirmed": True})
                try:
                    native_code = process.wait(timeout=timeout)
                    outcome = "exited"
                    receiver_code = native_code if 0 <= native_code <= 255 else 1
                except subprocess.TimeoutExpired:
                    native_code = _kill_and_reap(process)
                    outcome, receiver_code = "timed_out", 124
                except KeyboardInterrupt:
                    native_code = _kill_and_reap(process)
                    outcome, receiver_code = "interrupted", 130
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
    except (OSError, ValueError, KeyboardInterrupt) as exc:
        detail = f"{type(exc).__name__}: {exc}"
        outcome = "interrupted" if isinstance(exc, KeyboardInterrupt) else "receiver_error"
        receiver_code = 130 if outcome == "interrupted" else 74
        if process is not None:
            native_code = _kill_and_reap(process)

    # Post-observation failures never erase a known native completion code.
    after, inspection_errors = [], []
    for path in paths:
        try:
            after.append(_snapshot(path))
        except (OSError, ValueError) as exc:
            after.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
            inspection_errors.append(str(exc))
    logs = {}
    for name in ("stdout.bin", "stderr.bin"):
        try:
            logs[name] = _snapshot(output / name)
        except (OSError, ValueError) as exc:
            logs[name] = {"error": f"{type(exc).__name__}: {exc}"}
            inspection_errors.append(str(exc))
    if inspection_errors:
        receiver_code = 74
    receipt = {**started, "state": outcome, "pid": process.pid if process is not None else None,
               "child_start_confirmed": process is not None,
               "child_reaped": process is not None and native_code is not None,
               "child_returncode": native_code, "receiver_exit_code": receiver_code,
               "finished_ns": time.time_ns(), "elapsed_seconds": time.monotonic() - elapsed_start,
               "sources_after": after, "sources_unchanged": before == after,
               "logs": logs, "inspection_errors": inspection_errors, "detail": detail,
               "termination_scope": "direct child only; descendants are not tracked"}
    try:
        _write_record(output / "receipt.json", receipt)
    except (OSError, ValueError) as exc:
        print(f"receive-local: terminal receipt unavailable: {exc}; native code={native_code!r}",
              file=sys.stderr)
        return 74
    print(str(output / "receipt.json"))
    return receiver_code


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, help="new directory; parent must exist")
    parser.add_argument("--cwd", required=True, help="existing child working directory")
    parser.add_argument("--timeout", required=True, type=float, help="positive finite seconds")
    parser.add_argument("--source", action="append", default=[],
                        help="regular file to hash before/after; relative to cwd; repeatable")
    parser.add_argument("command", nargs=argparse.REMAINDER, help="-- /absolute/program arguments")
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    try:
        return receive(command, args.cwd, args.output_dir, args.timeout, args.source)
    except (OSError, ValueError) as exc:
        print(f"receive-local: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
