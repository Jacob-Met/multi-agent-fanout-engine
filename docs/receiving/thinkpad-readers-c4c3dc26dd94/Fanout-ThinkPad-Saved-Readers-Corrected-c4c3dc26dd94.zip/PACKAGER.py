"""Exclusive cloud packaging of the admitted immutable evidence; no product call."""
import hashlib,json,pathlib,stat,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
STAGE=ROOT/'packet'
ARCHIVE=ROOT/'Fanout-ThinkPad-Saved-Readers-c4c3dc26dd94.zip'
def pins(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def identity(p):
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):raise RuntimeError('nonregular input: '+str(p))
    for parent in p.parents:
        if not stat.S_ISDIR(parent.lstat().st_mode):raise RuntimeError('unsafe ancestor: '+str(parent))
    return dict(pins(p.read_bytes()),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
def safe(n):
    p=pathlib.PurePosixPath(n)
    if p.is_absolute() or '..' in p.parts or '\\' in n or ':' in n or str(p)!=n:raise RuntimeError('unsafe path: '+n)
intake=json.loads((ROOT/'INTAKE.json').read_bytes())
files={n:ROOT/'inputs'/n for n in intake['provenance']}
files.update({'evidence/INTAKE.json':ROOT/'INTAKE.json','evidence/prepare.py':ROOT.parent/'fanout-portable-intake/prepare.py','PACKAGER.py':ROOT/'PACKAGER.py','VERIFY.py':ROOT/'VERIFY.py','START-HERE.md':ROOT/'START-HERE.md'})
if len(files)!=77 or len({str(p) for p in files.values()})!=77:raise RuntimeError('input count differs')
before={n:identity(p) for n,p in files.items()}
for n,p in intake['provenance'].items():
    if any(before[n][k]!=p[k] for k in ('bytes','sha256','git')):raise RuntimeError('admitted bytes changed: '+n)
if len({n.casefold() for n in files})!=len(files):raise RuntimeError('case collision')
for n in files:safe(n)
STAGE.mkdir(mode=0o700)
payload={n:p.read_bytes() for n,p in files.items()}
source={'schema':'fanout.saved-readers.portable.c4c3dc26dd94.v1','source_commit':intake['source_commit'],'source_tree':intake['source_tree'],'source_publication':'Final additive guide/installer/archive publication follows this immutable packet; no final PR commit asserted here.','cloud_inputs':before,'native_descriptor_files':86,'native_exact_body_correspondences':69,'native_descriptor_only_count':17,'coverage_detail':'evidence/INTAKE.json','git_objects':{n:p['git'] for n,p in intake['provenance'].items()},'boundary':'Native build/stage evidence and exact source projections; native activation raw bodies absent. Transcript checkpoint retains direct-read outcome attribution. Not a portable venv or automatic installer.'}
payload['SOURCE.json']=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()
manifest={'schema':'fanout.portable.manifest.v1','files':{n:pins(b) for n,b in payload.items()}}
payload['MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
for n,b in payload.items():
    safe(n);p=STAGE/n;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
with zipfile.ZipFile(ARCHIVE,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):
        info=zipfile.ZipInfo(n,(2026,10,13,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|0o600)<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
with zipfile.ZipFile(ARCHIVE) as z:
    if len(z.infolist())!=79 or set(z.namelist())!=set(payload) or z.testzip() is not None:raise RuntimeError('archive membership/CRC mismatch')
    for n,b in payload.items():
        if z.read(n)!=b or (STAGE/n).read_bytes()!=b:raise RuntimeError('full byte readback differs')
after={n:identity(p) for n,p in files.items()}
if before!=after:raise RuntimeError('cloud input identity changed')
receipt={'schema':'fanout.portable.packaging.c4c3dc26dd94.v1','accepted':True,'archive':str(ARCHIVE),**pins(ARCHIVE.read_bytes()),'members':79,'manifest_payloads':78,'cloud_inputs':77,'native_exact_body_correspondences':69,'native_descriptor_only_count':17,'before':before,'after':after,'all_inputs_unchanged':True,'execution':'data-only cloud assembly; no current native identity reinspection; no product or installer invocation'}
with (ROOT/'package-receiving.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('before','after')}))
