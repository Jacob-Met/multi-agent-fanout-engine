"""Data-only verification of this extracted packet; no installer or product import."""
import hashlib,json,pathlib,stat
ROOT=pathlib.Path(__file__).resolve().parent
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
manifest=json.loads((ROOT/'MANIFEST.json').read_bytes())['files']
actual={}
for p in ROOT.rglob('*'):
    s=p.lstat()
    if stat.S_ISDIR(s.st_mode):continue
    if not stat.S_ISREG(s.st_mode):raise SystemExit('nonregular packet member: '+str(p))
    n=p.relative_to(ROOT).as_posix()
    if n!='MANIFEST.json':actual[n]=pin(p.read_bytes())
if actual!=manifest:raise SystemExit('packet membership or bytes differ')
source=json.loads((ROOT/'SOURCE.json').read_bytes())
intake=json.loads((ROOT/'evidence/INTAKE.json').read_bytes())
freeze=json.loads((ROOT/'native/FREEZE.json').read_bytes())
if set(intake['body_coverage'])|set(intake['descriptor_only'])!=set(freeze['files']):raise SystemExit('native coverage partition differs')
if set(intake['body_coverage'])&set(intake['descriptor_only']):raise SystemExit('native coverage overlap')
for original,row in intake['body_coverage'].items():
    b=(ROOT/row['member']).read_bytes();p=pin(b);expected=freeze['files'][original]
    if any(p[k]!=expected[k] for k in p):raise SystemExit('recorded native body mismatch: '+original)
for n,p in source['git_objects'].items():
    if pin((ROOT/n).read_bytes())['git']!=p:raise SystemExit('source object differs: '+n)
print(json.dumps({'accepted':True,'payloads':len(actual),'native_body_correspondences':len(intake['body_coverage']),'native_descriptors_only':len(intake['descriptor_only']),'source_objects':len(source['git_objects']),'execution':'integrity only; no installer/product/native operation'}))
