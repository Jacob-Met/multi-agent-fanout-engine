# Open the saved Fanout sample

After extracting this ZIP, open **native/stage/sample-review.html** in a browser. It is the exact 22,980-byte page produced during the accepted ThinkPad receiving, with seven fictional parts, their recorded states, dependencies and history. Its embedded inspection JSON is byte-equal to **native/stage/inspect.stdout.bin**. The page has no JavaScript, automatic refresh, browser storage or network resources. This delivery adds no fresh browser visual test.

The fictional database is **native/stage/authored-sample.sqlite**. It is a received example, not current estate task status. The exact saved inspection, project list and history are the corresponding stdout.bin files in that directory.

## Use the received command on the ThinkPad

The user-owned **hamon-fanout-read** command was installed and received for jacob on hamon-thinkpad at source **639038bb09a14b54109efd2df2e699a22484a815**, tree **fbb6e1317c2b733539f36335d89fdc6ad39be351**. Read [the current operator guide](docs/THINKPAD-READERS.md) for its explicit database arguments, four routes and identity-conditional withdrawal instructions. The guide records nine staged checks and two actual inherited-PATH checks; withdrawal was not executed.

The bundled runtime-source directory is an exact nineteen-module source projection plus the authored example generator. Its bytes match both the accepted wheel and recorded installed hashes. It is not a portable copy of the private native venv. The native wrapper is descriptor-only. Do not run the dated installer on another machine or treat extraction as installation.

## What the packet contains

- **build/Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip**: the original complete 37-member cloud build capsule once, including 23 source objects, the received wheel, build manifest and complete helper records. Wheel SHA-256 is 29b74d701c5f088357bc19c3c7cf95b3f8226edddba379a82669b4c46a25d5ad. No wheel build or product course was repeated for this packet.
- **native/**: all 44 exact staged-export members, the original native guide, installer, helper and build-history checkpoint. The early stage ZIP container is not duplicated.
- **native/FREEZE.json**: all 86 original native regular-file descriptors and the installed alias descriptor, preserved with exact Python integer values. No symlink is recreated.
- **evidence/INTAKE.json**: exact coverage and source provenance. Sixty-nine frozen native bodies have byte-equal representations here, including runtime bytes from the accepted build. Seventeen entries have descriptors only: installation/activation/connector records, phase drivers and the wrapper. These missing bodies are individually enumerated; hashes are not represented as their contents.
- **evidence/activation-transcript-checkpoint.json**: explicitly transcript-derived activation/outer observations and retained prior direct-read reviewer acceptance. It is not a reconstituted raw receipt. Before the refresh, the complete native activation and installation records were independently read; the later offline route prevents a new native inspection here.

The source snapshot is [the accepted repository commit](https://github.com/Jacob-Met/multi-agent-fanout-engine/tree/639038bb09a14b54109efd2df2e699a22484a815). The final additive installation-guide/packet publication necessarily follows these frozen bytes and is linked by the delivery record. Original evidence and earlier failures remain attributed: the first cloud build's lost files are recorded as transcript-derived history; the complete retained rebuild is the included capsule.

## Optional data-only integrity check

From the extracted packet directory, run `python3 -I -B VERIFY.py`. It reads only this packet, requires the exact manifest set and bytes, and checks the full native coverage partition and Git object map. It never executes the installer, generator, readers or browser. The packaging code also retained exact before/after cloud input identities; those are not claimed as a fresh inspection of the offline native machine.

Recorded readiness does not reserve a worker; unknown outcomes remain unknown. The accepted readers require an explicit existing database and create-only output paths. Their read-only ledger semantics do not promise that SQLite performs no read-side WAL bookkeeping. This packet makes no service, live-ledger, dispatch or broader runtime adoption claim beyond the received user-owned ThinkPad command.
