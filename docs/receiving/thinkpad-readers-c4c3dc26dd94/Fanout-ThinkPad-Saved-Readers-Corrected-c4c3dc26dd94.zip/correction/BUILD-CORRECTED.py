"""One versioned editorial correction; original archive and all product bytes preserved."""
import hashlib,json,pathlib,stat,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT/'Fanout-ThinkPad-Saved-Readers-c4c3dc26dd94.zip'
NEW=ROOT/'Fanout-ThinkPad-Saved-Readers-Corrected-c4c3dc26dd94.zip'
def pins(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def identity(p):
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):raise RuntimeError('nonregular input')
    return dict(pins(p.read_bytes()),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
before={str(p):identity(p) for p in [OLD,pathlib.Path(__file__)]}
if before[str(OLD)]['sha256']!='7ac0bee95d6f9239e4c57419d54f1e622c2f6e5c27c554ea0b3b49b264bf6a7a':raise RuntimeError('original archive differs')
with zipfile.ZipFile(OLD) as z:
    if len(z.infolist())!=79 or z.testzip() is not None:raise RuntimeError('original ZIP differs')
    data={i.filename:z.read(i) for i in z.infolist()}
    if len(data)!=79:raise RuntimeError('duplicate original member')
    for i in z.infolist():
        p=pathlib.PurePosixPath(i.filename)
        if p.is_absolute() or '..' in p.parts or '\\' in i.filename or ':' in i.filename or str(p)!=i.filename or i.is_dir() or stat.S_IFMT(i.external_attr>>16)!=stat.S_IFREG:raise RuntimeError('unsafe original member')
old_manifest=json.loads(data['MANIFEST.json'])['files']
if {n:pins(b) for n,b in data.items() if n!='MANIFEST.json'}!=old_manifest:raise RuntimeError('original manifest differs')
original=data['START-HERE.md'];old=b'their recorded states, dependencies and history.';new=b'their recorded states, dependency readiness and part details.'
if original.count(old)!=1:raise RuntimeError('editorial beforeimage differs')
corrected=original.replace(old,new)
data['START-HERE.md']=corrected
data['correction/ORIGINAL-START-HERE.md']=original
data['correction/BUILD-CORRECTED.py']=pathlib.Path(__file__).read_bytes()
correction={'schema':'fanout.opening.editorial-correction.v1','original_archive':pins(OLD.read_bytes()),'reason':'The sample HTML shows states, dependency readiness and part details. Event history is in native/stage/history.stdout.bin; it is not displayed as an HTML history view.','before':old.decode(),'after':new.decode(),'original_opening':pins(original),'corrected_opening':pins(corrected),'change_scope':'One sentence substitution only. All original product/runtime/native evidence bytes and admitted descriptor maps remain exact. No installer, product, browser or native receiving rerun. First packet is superseded as an opening guide, not erased.'}
data['CORRECTION.json']=(json.dumps(correction,indent=2)+'\n').encode()
source=json.loads(data['SOURCE.json'])
source['cloud_input_scope']='Retained first-packet 77-input before map. START-HERE.md entry is the original preserved at correction/ORIGINAL-START-HERE.md; the current opening substitution is bound in CORRECTION.json. These are not fresh native observations.'
source['editorial_correction']=correction
data['SOURCE.json']=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()
data['MANIFEST.json']=(json.dumps({'schema':'fanout.portable.manifest.v1','files':{n:pins(b) for n,b in data.items() if n!='MANIFEST.json'}},indent=2)+'\n').encode()
if len(data)!=82:raise RuntimeError('corrected member count differs')
with zipfile.ZipFile(NEW,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(data.items()):
        i=zipfile.ZipInfo(n,(2026,10,13,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o600)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
with zipfile.ZipFile(NEW) as z:
    if set(z.namelist())!=set(data) or z.testzip() is not None:raise RuntimeError('corrected membership/CRC')
    for n,b in data.items():
        if z.read(n)!=b:raise RuntimeError('corrected bytes differ')
after={p:identity(pathlib.Path(p)) for p in before}
if before!=after:raise RuntimeError('original input changed')
receipt={'accepted':True,'archive':str(NEW),**pins(NEW.read_bytes()),'members':82,'payloads':81,'before':before,'after':after,'original_inputs_unchanged':True,'correction':correction}
with (ROOT/'corrected-package-receiving.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['before','after','correction']}))
