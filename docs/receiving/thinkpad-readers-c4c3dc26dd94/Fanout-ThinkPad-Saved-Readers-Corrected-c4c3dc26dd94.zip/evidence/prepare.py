import ast, base64, csv, hashlib, io, json, pathlib, re, stat, zipfile
ROOT = pathlib.Path('/dev/shm/estate_delivery-c4c3dc26dd94')
IN = ROOT / 'fanout-portable-intake'
OUT = ROOT / 'fanout-portable-delivery'
def pins(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def checked(b,p):
    a=pins(b)
    for k in a:
        if k in p: assert a[k]==p[k], (k,a[k],p[k])
    return a
def typed(a,b):
    assert type(a) is type(b)
    if isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a: typed(a[k],b[k])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):typed(x,y)
    else: assert a==b
def readzip(raw,count):
    z=zipfile.ZipFile(io.BytesIO(raw)); rows=z.infolist(); assert len(rows)==count
    names=[x.filename for x in rows];assert len(set(n.casefold() for n in names))==count
    for x in rows:
        p=pathlib.PurePosixPath(x.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename and ':' not in x.filename
        assert str(p)==x.filename and not x.is_dir() and not x.flag_bits & 1
        assert stat.S_IFMT(x.external_attr>>16) in (0,stat.S_IFREG)
    assert z.testzip() is None
    return {n:z.read(n) for n in names}
raws={
 'build':(ROOT/'Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip').read_bytes(),
 'stage':(IN/'staged-raw-export.zip').read_bytes(),
 'freeze':(ROOT/'fanout-native-FREEZE.json').read_bytes()}
checked(raws['build'],{'bytes':114764,'sha256':'f6bacba529169097b44804a3fe1ba63c4e778d569ac585b9e389ba1cf12ab65b','git':'f5e3d7f8862e764ae70ce3ba1e3380df4d23a1df'})
checked(raws['stage'],{'bytes':27493,'sha256':'2ebef7612586df7986b7f4fa51db62b9cfd91f5a6d25393ff5383c6188a3a7a7','git':'31b7ee151b7c126c7abd6e11a1b2fa77dbbd0043'})
checked(raws['freeze'],{'bytes':41909,'git':'4b315d4ed346e200b84d2b34edcb55c8c77e1eb9'})
build=readzip(raws['build'],37);stage=readzip(raws['stage'],44);freeze=json.loads(raws['freeze'])
bm=json.loads(build['BUILD-MANIFEST.json'])['files'];assert set(bm)==set(build)-{'BUILD-MANIFEST.json'}
for n,b in build.items():
    if n in bm:checked(b,bm[n])
pub=json.loads(build['published-source.json']);assert len(pub['files'])==23
for n,p in pub['files'].items(): checked(build['source/'+n],p)
br=json.loads(build['cloud-build-receipt.json']);typed(br['before'],br['after']);assert len(br['before'])==23 and br['helper_returncode']==0 and br['all_inputs_unchanged']
for n,p in br['before'].items():checked(build['source/'+n],p)
def helper(d,prefix):
    r=json.loads(d[prefix+'receipt.json']);assert r['state']=='exited' and r['child_start_confirmed'] and r['child_reaped'] and r['child_returncode']==r['receiver_exit_code']==0
    assert r['sources_unchanged'] and not r['inspection_errors'];typed(r['sources_before'],r['sources_after'])
    for n,p in r['logs'].items():checked(d[prefix+n],p)
    return r
bh=helper(build,'build-job/');sh=helper(stage,'stage-job/');assert bh['pid']==6 and sh['pid']==360984
assert build['build-job/stdout.bin']==build['wheel/COMPLETE.json'] and not build['build-job/stderr.bin']
wheelname='multi_agent_fanout_engine-0.1.0-py3-none-any.whl';wraw=build['wheel/'+wheelname]
checked(wraw,{'bytes':41768,'sha256':'29b74d701c5f088357bc19c3c7cf95b3f8226edddba379a82669b4c46a25d5ad'})
wheel=readzip(wraw,23);recname='multi_agent_fanout_engine-0.1.0.dist-info/RECORD';records=list(csv.reader(io.StringIO(wheel[recname].decode())))
assert len(records)==len(wheel) and {r[0] for r in records}==set(wheel)
for n,digest,size in records:
    if n==recname: assert digest==size==''
    else: assert digest=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(wheel[n]).digest()).decode().rstrip('=') and int(size)==len(wheel[n])
modules={n:b for n,b in wheel.items() if n.startswith('fanout_engine/')};assert len(modules)==19
for n,b in modules.items():assert b==build['source/'+n]
wb=json.loads(build['wheel/source-build.json']);assert wb['build']['returncode']==0
for n,p in wb['source']['files'].items(): checked(build['source/'+n],dict(p,git=p['git_blob']))
for n,p in wb['build']['logs'].items():checked(build['wheel/build.'+n],p)
sr=json.loads(stage['staged-receipt.json']);assert sr['all_checks_passed'] and sr['live_ledger_used'] is False and len(sr['runtime'])==25
assert sr['source_commit']==freeze['source_commit']=='639038bb09a14b54109efd2df2e699a22484a815'
assert len(sr['observations'])==9
for r in sr['observations']:
    n=r['label'];assert r['returncode']==r['expected_exit'] and r['child_reaped'] and not r['timed_out']
    row=json.loads(stage['stage/'+n+'.json']);typed({k:v for k,v in r.items() if k!='label'},row)
    for stream in ['stdout','stderr']:checked(stage['stage/'+n+'.'+stream+'.bin'],r[stream])
for n in ['venv','install-wheel','fixture']:
    r=json.loads(stage['stage/'+n+'.json']);assert r['returncode']==0 and r['child_reaped'] and not r['timed_out']
    for stream in ['stdout','stderr']:checked(stage['stage/'+n+'.'+stream+'.bin'],r[stream])
page=stage['stage/sample-review.html'];m=re.search(rb'href="data:application/json;base64,([A-Za-z0-9+/=]+)"',page)
assert m and base64.b64decode(m[1],validate=True)==stage['stage/inspect.stdout.bin'] and len(stage['stage/inspect.stdout.bin'])==3544
assert not re.search(rb'<script\b',page,re.I)
for n,b in stage.items():checked(b,freeze['files'][n])
for key,p in freeze['files'].items():
    if key.startswith('runtime/'):
        native=p['native_path'];assert native in sr['runtime']
        typed({k:v for k,v in p.items() if k!='native_path'},sr['runtime'][native])
inputs={};provenance={};coverage={}
def add(n,b,origin,native=None):
    assert n not in inputs;inputs[n]=b;provenance[n]={'origin':origin,**pins(b)}
    if native is not None:
        checked(b,freeze['files'][native]);coverage[native]={'member':n,'provenance':origin}
add('build/Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip',raws['build'],'exact immutable cloud build capsule','Fanout-Current-Reader-Wheel-Build-c4c3dc26dd94.zip')
for n,b in stage.items():add('native/'+n,b,'exact member of immutable 44-file native staged export',n)
add('native/FREEZE.json',raws['freeze'],'complete original native 86-file descriptor map')
for src,dst,native,git in [
 ('native-guide.md','native/README.md','README.md','57ec5d828023ff9913065fe902326fe17b428271'),
 ('install_readers.py','native/install_readers.py','install_readers.py','d3d1ae6272d7c027a5f14cc1b057ffbe31ab9612'),
 ('build-custody-checkpoint.json','native/build-custody-checkpoint.json','build-custody-checkpoint.json','35165951fbb84bf19d84bd3ac257543b7b73feb5'),
 ('published-guide.md','docs/THINKPAD-READERS.md',None,'52fcc1b9288b78f0c6b4f56eec5623cc97bd87a2'),
 ('activation-transcript-checkpoint.json','evidence/activation-transcript-checkpoint.json',None,'ddc83d035f95ce976d86341e9e4dd09f66f97864')]:
    b=(IN/src).read_bytes();checked(b,{'git':git});add(dst,b,'exact immutable Git text; source/history classification retained',native)
add('native/receive_local.py',build['receive_local.py'],'exact shared helper from pinned build capsule','receive_local.py')
for n,b in modules.items():add('runtime-source/'+n,b,'wheel member and accepted source byte-equal to recorded installed pin','runtime/'+n)
add('runtime-source/examples/create_retained_ledger.py',build['source/examples/create_retained_ledger.py'],'accepted build source byte-equal to recorded installed pin','runtime/examples/create_retained_ledger.py')
assert (IN/'published-guide.md').read_bytes().startswith((IN/'native-guide.md').read_bytes())
missing={n:p for n,p in freeze['files'].items() if n not in coverage}
assert len(freeze['files'])==86 and len(coverage)+len(missing)==86
report={'schema':'fanout.portable.intake.c4c3dc26dd94.v1','accepted':True,'source_commit':freeze['source_commit'],'source_tree':freeze['source_tree'],'build_members':37,'build_source_objects':23,'wheel_members':23,'runtime_modules':19,'complete_stage_files':44,'stage_observations':9,'stage_setup_children':3,'native_descriptor_files':86,'body_coverage_count':len(coverage),'descriptor_only_count':len(missing),'body_coverage':coverage,'descriptor_only':missing,'descriptors':freeze['descriptors'],'provenance':provenance,'scope':'Data-only immutable capsule receiving. No product execution and no current native identity reinspection. Runtime source projection matches frozen installed pins but is not an exported venv. Activation checkpoint is transcript-derived.'}
OUT.mkdir(mode=0o700);source=OUT/'inputs';source.mkdir()
for n,b in inputs.items():
    p=source/n;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
with (OUT/'INTAKE.json').open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'accepted':True,'payload_inputs':len(inputs),'covered_native_bodies':len(coverage),'descriptor_only':list(missing),'html_bytes':len(page),'wheel_record_entries':len(records)}))
