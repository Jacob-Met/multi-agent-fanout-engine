"""Verify exact extracted membership and bodies; never import packaged product code."""
import hashlib, json, pathlib, stat
ROOT = pathlib.Path(__file__).resolve().parent
def pin(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
            'git': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}
manifest = json.loads((ROOT / 'MANIFEST.json').read_bytes())['files']
actual = {}
for p in ROOT.rglob('*'):
    mode = p.lstat().st_mode
    if stat.S_ISDIR(mode):
        continue
    if not stat.S_ISREG(mode):
        raise SystemExit('Nonregular member: ' + str(p))
    name = p.relative_to(ROOT).as_posix()
    if name != 'MANIFEST.json':
        actual[name] = pin(p.read_bytes())
if actual != manifest or len(actual) != 98:
    raise SystemExit('Extracted set or payload bytes differ')
freeze = json.loads((ROOT / 'evidence/PACKET-FREEZE.json').read_bytes())
source = json.loads((ROOT / 'SOURCE.json').read_bytes())
if source['native_inputs'] != freeze['native_files'] or len(freeze['native_files']) != 34:
    raise SystemExit('Native source map differs')
if source['alias_descriptor'] != freeze['native_alias'] or source['preserved_runtime_descriptors'] != freeze['protected_runtime']:
    raise SystemExit('Preserved descriptors differ')
for name, row in freeze['native_files'].items():
    if any(actual[row['packet_path']][k] != row['identity'][k] for k in actual[row['packet_path']]):
        raise SystemExit('Native body mismatch: ' + name)
for name, git in source['git_objects'].items():
    if actual[name]['git'] != git:
        raise SystemExit('Git identity differs: ' + name)
print(json.dumps({'accepted': True, 'payloads': len(actual), 'native_bodies': 34,
                  'execution': 'Integrity only; no product, installer or native operation'}))
