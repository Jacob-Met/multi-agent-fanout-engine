# Reach the accepted blocker reader from the installed command

Frozen before authoring the new wrapper. Repository: Jacob-Met/multi-agent-fanout-engine.
Current main 2104d83c208830807989ce90d2ec65d523bb4822 already contains the
authored blockers module 8cdc09f08c7096ca5313ed80ed1cef0148bb977b, accepted
through PR85; PR59 comment 6148132068 records the owner handoff. The installed
639038bb09a1 package has that exact module, but wrapper1878178 exposes only
projects, inspect, history and review. No blocker implementation change is proposed.

## Original witness

Freshly admit hamon-thinkpad, jacob UID/GID1000, pinned Python3.14.4, actual
inherited PATH resolution, alias450135, all25 recorded runtime identities,
historical installation receipt and the already-authored sample database.
Invoke actual `/usr/bin/env hamon-fanout-read blockers --database FILE --project sample`
once. Expected original observation: exit2, empty stdout, exact four-route
wrapper refusal. This records the missing entry; it is not a desired success.
Retain both raw streams, bounded child outcome and all before/after identities.

## Desired new route

The same command must return exit0, empty stderr and the exact complete
`expected-blockers.json` bytes. The previously authored sample supplies a real
recorded queued `publish` part blocked by running `draft` and outcome_unknown
`verify`, in declaration order; `notes` is ready because its source is complete.
No dispatch/retry inference is made from those recorded states.

Retain two narrow refusal controls: `blockers --project sample` exits2 with an
argparse missing --database diagnostic and no stdout; `dispatch` exits2 with the
wrapper's explicit allowlist diagnostic and no stdout. No default database is
selected, no output export is requested, and no existing source/ledger changes.
All25 original runtime identities, original wrapper/version, fixture and alias
beforeimages are preserved; only a guarded alias switch to a new wrapper version
may occur after source and staged-result review. The new wrapper reuses the
unchanged qualified private venv with -I -B. No venv installation or upgrade.

The staged route receives these three observations once. After guarded activation,
one actual inherited-environment named command receives the exact blocker report;
identities bind the same staged wrapper and original runtime. No old four-route
matrix, existing blocker source suite, queue workflow or remote provider repeats.
Each direct child has a four-second timeout and kill/communicate/reap. This is
ordinary owned-fixture receiving, not a process-tree/OS sandbox guarantee.
