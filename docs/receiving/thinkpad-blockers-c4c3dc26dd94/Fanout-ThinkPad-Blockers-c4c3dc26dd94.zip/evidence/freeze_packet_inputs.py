"""Freeze only the explicit completed blockers course and operator source."""
from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent
def pin(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode)
 b=p.read_bytes();z=p.lstat();assert (s.st_dev,s.st_ino,s.st_mtime_ns,s.st_size)==(z.st_dev,z.st_ino,z.st_mtime_ns,z.st_size) and len(b)==s.st_size
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
original=json.loads((ROOT/'ORIGINAL-FREEZE.json').read_bytes())
files={}
for name,want in original['files'].items():
 got=pin(ROOT/name)
 assert all(got[k]==want[k] for k in ('bytes','sha256','git','mtime_ns')) and got['dev']==want['device'] and got['ino']==want['inode']
 files['original/'+name]=got
final=json.loads((ROOT/'final-export.json').read_bytes())
for name,row in final['files'].items():
 got=pin(ROOT/'final-export-exact'/name);want=row['identity'];assert all(got[k]==want[k] for k in ('bytes','sha256','git'))
 files['native/'+name]=got
extras=['ORIGINAL-FREEZE.json','install_blockers_entry.first.py','updater-review-correction.patch','setup_inputs.py','setup_inputs_v2.py','setup_inputs_final.py','input-setup-receipt.json','009-setup-parse-note.json','006-stage-config.json','007-input-setup-start.json','008-input-setup-terminal.json','010-stage-start.json','011-stage-terminal.json','012-stage-export-start.json','013-stage-export-terminal.json','016-activation-start.json','017-activation-terminal.json','018-final-export-start.json','019-final-export-terminal.json','stage-command.json','activation-command.json','export_stage.py','export_final.py','wrapper.patch','wrapper-proof.json','source-review-history.json','navigation-peer.json','README.repository.original.md','README.repository.md','README.repository.patch']
for name in extras+['freeze_packet_inputs.py']:files['evidence/'+name]=pin(ROOT/name)
for name in ('README.md','install_blockers_entry.py','hamon-fanout-read','expected-blockers.json'):files['operator/'+name]=pin(ROOT/name)
for name in ('fanout-blockers-stage-review.json','fanout-blockers-final-review.json'):files['peer/'+name]=pin(Path('/dev/shm/root-current-readers-c4c3dc26dd94')/name)
assert len(files)==len(set(files))
for name,row in files.items():assert pin(Path(row['path']))==row,name
value={'schema':'fanout.blockers.completed-inputs.v1','scope':'Complete actual course cloud copies, 34 exact native bodies, preserved original20 and source/history; alias and old25 runtime remain descriptors in receipts, no old venv copy','files':files,'native_files':{name:{'path':row['path'],'identity':row['identity'],'packet_path':'native/'+name} for name,row in final['files'].items()},'native_alias':final['alias'],'protected_runtime':final['after'],'original20_unchanged':True,'native_inputs_unchanged_at_export':final['all_inputs_unchanged'],'guide_git':files['operator/README.md']['git'],'no_new_product_execution':True}
with (ROOT/'PACKET-FREEZE.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({'files':len(files),'native_bodies':len(final['files']),'original_files':len(original['files']),'guide_git':value['guide_git']}))
