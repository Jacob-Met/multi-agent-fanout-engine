"""Read-only export of the completed activation; no installer phase or child invocation."""
from pathlib import Path
import base64,hashlib,importlib.util,json
ROOT=Path('/home/jacob/fanout-blockers-20261014-c4c3dc26dd94')
p=ROOT/'install_blockers_entry.py'
b=p.read_bytes()
assert hashlib.sha256(b).hexdigest()=='888a16fdc01aa6be761bcd9a9645074019803134d4c4d074ea0d50a603dc987e'
spec=importlib.util.spec_from_file_location('reviewed_blockers_updater',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original,history,wrapper,expected=m.inputs();before=m.preserved(original,history);stage=m.staged(wrapper)
installed=json.loads(m.read(ROOT/'installation-receipt.json')[0])
assert stage['before']==stage['after']==before==installed['before']==installed['after']
assert m.link(m.ALIAS)==installed['alias'] and installed['old_alias']==history['alias_identity']==stage['old_alias']
assert installed['wrapper']==stage['wrapper'] and installed['source_inputs']==stage['source_inputs'] and installed['all_checks_passed']
names=['install_blockers_entry.py','hamon-fanout-read','original-receipt.json','expected-blockers.json','CRITERIA.md','receive_original_v2.py','wrapper.patch','wrapper-proof.json','receive_local.py','staged-receipt.json']
names += ['stage/'+label+'.'+ext for label in ('blockers','missing-database','reject-dispatch') for ext in ('json','stdout.bin','stderr.bin')]
names += ['stage-job/'+name for name in ('started.json','spawned.json','receipt.json','stdout.bin','stderr.bin')]
names += ['installation-receipt.json']+['installed/blockers-inherited.'+ext for ext in ('json','stdout.bin','stderr.bin')]
names += ['activation-job/'+name for name in ('started.json','spawned.json','receipt.json','stdout.bin','stderr.bin')]
paths=[(n,ROOT/n) for n in names]+[('version/hamon-fanout-read',m.VERSION/'hamon-fanout-read')]
files={}
for name,path in paths:
 data,identity=m.read(path);files[name]={'path':str(path),'identity':identity,'base64':base64.b64encode(data).decode()}
after=m.preserved(original,history)
assert before==after and m.link(m.ALIAS)==installed['alias']
assert all(m.read(Path(row['path']))[1]==row['identity'] for row in files.values())
print(json.dumps({'scope':'Read-only full final export; no product/installer phase executed','files':files,'before':before,'after':after,'alias':m.link(m.ALIAS),'version_directory':m.owned_dir(m.VERSION),'all_inputs_unchanged':True},separators=(',',':')))
