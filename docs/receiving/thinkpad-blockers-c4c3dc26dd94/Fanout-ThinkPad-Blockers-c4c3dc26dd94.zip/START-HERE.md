# ThinkPad Fanout blockers reader

The installed `hamon-fanout-read` command now accepts a fifth offline route,
`blockers`, for an explicitly selected saved database and project. This dated
ThinkPad change adds the command to the existing wrapper; the already qualified
package and private Python environment are preserved.

## Open the useful result

Open [the fictional JSON report](operator/expected-blockers.json). Its 519 bytes
are exactly the stdout received from both the staged wrapper and the actual
installed inherited-PATH command. `publish` is blocked by `draft` (running) and
`verify` (outcome_unknown), while `notes` is queued and ready. This report describes
the saved fictional sample; it does not query or operate a live queue.

Read [the installed-command guide](operator/README.md) for the actual ThinkPad
paths, examples, version dependencies and source-reviewed withdrawal limits.
Its adjacent [installer source](operator/install_blockers_entry.py) is retained
for review. Do not treat this packet as an automatic or portable installation:
the new wrapper depends on the previous ThinkPad version's private environment.

## What the evidence establishes

The original command refused `blockers` with exit 2. After the reviewed wrapper
change, three staged commands returned the expected 0/2/2 outcomes. One actual
inherited-PATH installed command then returned the complete 519-byte report at
exit 0 with empty stderr. All direct children were reaped within their bounds.
The earlier 25 runtime-file identities and saved database remained unchanged.
No previous four-reader matrix, wheel build, installation, browser or blocker
algorithm course was repeated for this delivery.

The packet contains all 91 explicitly frozen evidence/source mappings, including
34 complete exported native bodies, the original refusal, phase raw streams,
source/guide reviews and setup history. One fictional expected-report input is
mapped twice for convenient opening. The old runtime, interpreter links and
alias are descriptors in the receipts, not copied symlinks or a bundled venv.
The freeze is preserved intact, with the later Delivery factual review separate.

`MANIFEST.json` binds every payload; `SOURCE.json` keeps exact Python integer
metadata for the exported native files and the distinct current cloud inputs.
After extracting into a fresh directory, `python VERIFY.py` performs only
membership/hash/source-map checks. It does not run the product or installer.
The author packaging operation and later independent integrity receiving are
separate from the already completed native course.
