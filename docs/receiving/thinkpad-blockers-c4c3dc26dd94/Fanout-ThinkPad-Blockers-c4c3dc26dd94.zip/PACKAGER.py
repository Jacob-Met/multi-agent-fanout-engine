"""Build one immutable host-evidence packet from explicitly admitted cloud files."""
import hashlib, json, os, pathlib, stat, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
ARCHIVE = ROOT / 'Fanout-ThinkPad-Blockers-c4c3dc26dd94.zip'
STAGE = ROOT / 'packet'

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
            'git': hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()}

def safe(name):
    p = pathlib.PurePosixPath(name)
    require(bool(name) and not p.is_absolute() and p.as_posix() == name and
            all(x not in ('', '.', '..') and ':' not in x for x in p.parts) and
            '\\' not in name, 'unsafe member: ' + name)

def read(path):
    path = pathlib.Path(path)
    require(path.is_absolute(), 'input is not absolute')
    for p in [path.parent, *path.parent.parents]:
        require(stat.S_ISDIR(p.lstat().st_mode), 'non-directory parent: ' + str(p))
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode) and first.st_size <= 4 * 1024 * 1024, 'nonregular/oversized input')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as f:
        a = os.fstat(f.fileno())
        require((a.st_dev, a.st_ino) == (first.st_dev, first.st_ino), 'input replaced before read')
        body = f.read(4 * 1024 * 1024 + 1)
        b = os.fstat(f.fileno())
    last = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns')
    identity = lambda s: {k: getattr(s, k) for k in fields}
    require(identity(first) == identity(a) == identity(b) == identity(last), 'input changed while reading')
    require(len(body) == first.st_size, 'input length changed')
    return body, {**identity(first), **pin(body)}

inputs = json.loads((ROOT / 'INPUTS.json').read_bytes())
admitted = dict(inputs['files'])
for name in ('INPUTS.json', 'PACKAGER.py', 'VERIFY.py', 'START-HERE.md'):
    admitted[name] = {'path': str(ROOT / name)}
require(len(admitted) == 97, 'unexpected cloud input count')
require(len({x.casefold() for x in admitted}) == len(admitted), 'case-colliding members')
bodies, before = {}, {}
for name, row in admitted.items():
    safe(name)
    body, identity = read(row['path'])
    if 'sha256' in row:
        require(all(pin(body)[k] == row[k] for k in pin(body)), 'admitted body differs: ' + name)
        require(all(identity['st_'+k] == row[k] and type(identity['st_'+k]) is type(row[k]) for k in ('dev','ino','mode','uid','gid','mtime_ns')), 'admitted cloud identity differs: '+name)
    bodies[name], before[row['path']] = body, identity
require(len(before) == 96, 'unexpected distinct cloud input count')
freeze = json.loads(bodies['evidence/PACKET-FREEZE.json'])
require(pin(bodies['evidence/PACKET-FREEZE.json'])['sha256'] == inputs['freeze_sha256'], 'freeze differs')
require(len(freeze['files']) == 91 and len(freeze['native_files']) == 34, 'frozen counts differ')
for name,row in freeze['files'].items():
    require(all(pin(bodies[name])[k] == row[k] for k in pin(bodies[name])), 'frozen body differs: '+name)
for name,row in freeze['native_files'].items():
    require(all(pin(bodies[row['packet_path']])[k] == row['identity'][k] for k in pin(bodies[row['packet_path']])), 'native body differs: '+name)
source = {'schema': 'fanout.blockers.portable-source.v1',
          'source_commit': inputs['source_commit'], 'native_regular_inputs':34,
          'native_inputs':freeze['native_files'], 'alias_descriptor':freeze['native_alias'],
          'preserved_runtime_descriptors':freeze['protected_runtime'],
          'cloud_regular_inputs':len(before), 'cloud_members':len(admitted), 'cloud_inputs':before,
          'git_objects':{row['packet_path']:row['identity']['git'] for row in freeze['native_files'].values()},
          'scope':inputs['scope']}
bodies['SOURCE.json'] = (json.dumps(source, indent=2, ensure_ascii=False) + '\n').encode()
manifest = {'schema': 'fanout.blockers.portable-manifest.v1',
            'files': {n: pin(b) for n, b in bodies.items()}}
bodies['MANIFEST.json'] = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
require(len(bodies) == 99 and len(manifest['files']) == 98, 'archive counts differ')
STAGE.mkdir(mode=0o700)
for name, body in bodies.items():
    p = STAGE / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(body)
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, body in sorted(bodies.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 14, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o600) << 16
        z.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(ARCHIVE) as z:
    require(z.testzip() is None and set(z.namelist()) == set(bodies) and len(z.namelist()) == len(bodies), 'ZIP set/CRC differs')
    for name, body in bodies.items():
        require(z.read(name) == body == (STAGE / name).read_bytes(), 'roundtrip differs: ' + name)
after = {row['path']: read(row['path'])[1] for row in admitted.values()}
require(before == after, 'cloud input identities changed')
receipt = {'schema': 'fanout.blockers.package-receiving.v1', 'accepted': True,
           'archive': {**pin(ARCHIVE.read_bytes()), 'path': str(ARCHIVE)},
           'members': len(bodies), 'payloads': len(manifest['files']), 'native_bodies': 34,
           'cloud_inputs': len(before), 'before': before, 'after': after,
           'scope': 'Cloud byte-only packaging; no archived code, product, installer or native operation executed.'}
with (ROOT / 'package-receiving.json').open('x', encoding='utf-8') as f:
    json.dump(receipt, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in ('before', 'after')}, ensure_ascii=False))
