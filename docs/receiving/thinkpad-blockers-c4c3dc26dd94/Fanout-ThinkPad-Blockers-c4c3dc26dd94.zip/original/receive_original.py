"""Read-only installed-wrapper admission and one original refusal witness."""
from pathlib import Path
import base64,hashlib,json,os,pwd,shutil,socket,stat,subprocess,sys
OLD=Path('/home/jacob/.local/share/hamon-tools/hamon-fanout-read-639038bb09a1')
ALIAS=Path('/home/jacob/.local/bin/hamon-fanout-read')
WORK=Path('/home/jacob/fanout-readers-20261013-c4c3dc26dd94')
RECEIPT=WORK/'installation-receipt.json'
RECEIPT_SHA='fbb90e0d2c3c65ad78926a59653812767ea7325d439e82fa716b262b5bf954d3'
DATABASE=WORK/'stage/authored-sample.sqlite'
PYTHON=Path('/usr/bin/python3.14')
PYTHON_SHA='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
NEXT=Path('/home/jacob/fanout-blockers-20261014-c4c3dc26dd94')
VERSION=Path('/home/jacob/.local/share/hamon-tools/hamon-fanout-read-639038bb09a1-blockers-v1')
def require(v,m):
    if not v:raise RuntimeError(m)
def pins(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def fields(s):return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'size':s.st_size}
def ordinary(p):
    for parent in p.parents:require(stat.S_ISDIR(parent.lstat().st_mode),'nonordinary ancestor: '+str(parent))
    first=p.lstat();require(stat.S_ISREG(first.st_mode),'not ordinary: '+str(p))
    require(first.st_size<=8*1024*1024,'input too large')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        before=os.fstat(f.fileno());b=f.read(8*1024*1024+1);after=os.fstat(f.fileno())
    require(fields(first)==fields(before)==fields(after)==fields(p.lstat()) and len(b)==first.st_size,'input changed')
    return b,{**fields(first),**pins(b)}
def alias():
    s=ALIAS.lstat();require(stat.S_ISLNK(s.st_mode),'alias changed kind')
    return {**fields(s),'target':os.readlink(ALIAS)}
require(os.getuid()==os.geteuid()==os.getgid()==1000 and pwd.getpwuid(1000).pw_name=='jacob' and socket.gethostname()=='hamon-thinkpad','account/host differs')
require(Path(sys.executable).resolve()==PYTHON and sys.version_info[:3]==(3,14,4),'interpreter differs')
pyraw,python_before=ordinary(PYTHON);require(pins(pyraw)['sha256']==PYTHON_SHA,'Python bytes differ')
raw,receipt_before=ordinary(RECEIPT);require(pins(raw)['sha256']==RECEIPT_SHA,'historical receipt differs')
record=json.loads(raw);require(record['source_commit']=='639038bb09a14b54109efd2df2e699a22484a815' and record['all_checks_passed'],'historical source differs')
require(len(record['runtime'])==25,'runtime closure differs')
runtime_before={}
for name,expected in record['runtime'].items():
    p=Path(name);require(p.is_relative_to(OLD),'runtime escapes fixed old version')
    _,row=ordinary(p);require(row==expected and row['uid']==1000,'runtime identity differs: '+name);runtime_before[name]=row
require(runtime_before[str(OLD/'venv/lib/python3.14/site-packages/fanout_engine/blockers.py')]['git']=='8cdc09f08c7096ca5313ed80ed1cef0148bb977b','blocker source differs')
require(runtime_before[str(OLD/'hamon-fanout-read')]['git']=='1878178bb84f65d9ec6062b943697cfa17986b83','original wrapper differs')
alias_before=alias();require(alias_before==record['alias_identity'] and alias_before['target']==str(OLD/'hamon-fanout-read'),'historical alias differs')
require(shutil.which('hamon-fanout-read')==str(ALIAS),'inherited command resolution differs')
_,db_before=ordinary(DATABASE);require(db_before==record['fixture'],'sample fixture differs')
require(not os.path.lexists(NEXT) and not os.path.lexists(VERSION),'next owned destination exists')
dirs={}
for p in (Path('/home/jacob'),ALIAS.parent,OLD.parent,OLD,WORK,DATABASE.parent):
    s=p.lstat();require(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==1000,'owned directory differs');dirs[str(p)]=fields(s)
venv_python=OLD/'venv/bin/python';require(venv_python.resolve()==PYTHON,'venv interpreter target differs')
links={}
for p in (venv_python,OLD/'venv/bin/python3',OLD/'venv/bin/python3.14'):
    s=p.lstat();require(stat.S_ISLNK(s.st_mode) and s.st_uid==1000,'venv interpreter link differs');links[str(p)]={**fields(s),'target':os.readlink(p)}
argv=['/usr/bin/env','hamon-fanout-read','blockers','--database',str(DATABASE),'--project','sample']
child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=None)
timed_out=False
try:out,err=child.communicate(timeout=4)
except subprocess.TimeoutExpired:
    timed_out=True;child.kill();out,err=child.communicate()
runtime_after={name:ordinary(Path(name))[1] for name in runtime_before}
alias_after=alias();db_after=ordinary(DATABASE)[1]
unchanged=runtime_before==runtime_after and alias_before==alias_after and db_before==db_after and ordinary(RECEIPT)[1]==receipt_before and ordinary(PYTHON)[1]==python_before
refusal=child.returncode==2 and out==b'' and err==b'Use: hamon-fanout-read --help (projects, inspect, history, review only)\n'
result={'schema':'fanout.blockers.original-installed.v1','scope':'One actual inherited-environment original wrapper refusal, fixed fictional existing database argument, read-only identity admission. No candidate or native file mutation.','host':socket.gethostname(),'uid':os.getuid(),'gid':os.getgid(),'python':str(PYTHON),'python_identity':python_before,'inherited_path':os.environ.get('PATH'),'receipt':receipt_before,'alias_before':alias_before,'alias_after':alias_after,'runtime_before':runtime_before,'runtime_after':runtime_after,'database_before':db_before,'database_after':db_after,'directories':dirs,'venv_links':links,'observation':{'argv':argv,'pid':child.pid,'returncode':child.returncode,'reaped':child.poll() is not None,'timed_out':timed_out,'stdout_base64':base64.b64encode(out).decode(),'stderr_base64':base64.b64encode(err).decode(),'stdout':pins(out),'stderr':pins(err)},'original_refusal_observed':refusal,'all_inputs_unchanged':unchanged,'accepted_witness':refusal and unchanged and not timed_out and child.poll() is not None}
print(json.dumps(result,separators=(',',':')))
raise SystemExit(0 if result['accepted_witness'] else 1)
