#!/bin/sh
case "${1-}" in
  -h|--help) cat <<'FANOUT_HELP'
hamon-fanout-read: saved Fanout ledger readers
Usage:
  hamon-fanout-read projects --database FILE [--output NEW.json]
  hamon-fanout-read inspect  --database FILE --project ID [--output NEW.json]
  hamon-fanout-read history  --database FILE --project ID [--part ID] [--output NEW.json]
  hamon-fanout-read review   --database FILE --project ID --output NEW.html

FILE must be an explicitly selected existing local ledger. No default ledger is used.
Readers preserve recorded uncertainty; they do not dispatch, retry or reconcile work.
Exports require a new output path. SQLite may maintain read-side WAL bookkeeping.
Use a subcommand's --help for its exact options. Source: 639038bb09a1.
FANOUT_HELP
    exit 0 ;;
  projects|inspect|history|review) route=$1; shift ;;
  *) printf '%s\n' 'Use: hamon-fanout-read --help (projects, inspect, history, review only)' >&2; exit 2 ;;
esac
exec '/home/jacob/.local/share/hamon-tools/hamon-fanout-read-639038bb09a1/venv/bin/python' -I -B -m "fanout_engine.$route" "$@"
